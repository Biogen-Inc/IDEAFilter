library(testthat)
library(IDEAFilter)

test_check("IDEAFilter")
